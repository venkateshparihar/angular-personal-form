import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class FormService {
  constructor(private httpclient: HttpClient) {}
  postData(data: any): Observable<any> {
    return this.httpclient
      .post('http://localhost:23000/data', data)
      .pipe(catchError(data));
  }
}
