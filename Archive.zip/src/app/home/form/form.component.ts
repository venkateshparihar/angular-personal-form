import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormService } from '../form.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss'],
})
export class FormComponent implements OnInit {
  form: any;
  constructor(private formService: FormService) {}

  ngOnInit(): void {
    this.form = new FormGroup({
      fname: new FormControl(null, [Validators.required]),
      lname: new FormControl(null, Validators.required),
      contact_no: new FormControl(null, [Validators.required]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      gender: new FormControl(null, Validators.required),
      street_1: new FormControl(null, Validators.required),
      street_2: new FormControl(null, Validators.required),
      city: new FormControl(null, Validators.required),
      state: new FormControl(null, Validators.required),
      country: new FormControl(null, Validators.required),
    });
  }
  postData() {
    this.formService.postData(this.form.getRawValue()).subscribe();

    console.log(this.form.getRawValue());
  }
}
